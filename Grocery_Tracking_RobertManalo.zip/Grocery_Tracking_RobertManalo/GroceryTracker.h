#ifndef GROCERYTRACKER_H
#define GROCERYTRACKER_H

#include <map>
#include <string>

class GroceryTracker {
private:
    std::map<std::string, int> itemFrequency;
    std::string inputFileName;
    std::string backupFileName;

    std::string NormalizeItem(const std::string& item) const;

public:
    GroceryTracker(const std::string& inputFile, const std::string& backupFile);

    bool LoadData();
    bool CreateBackupFile() const;
    int GetItemFrequency(const std::string& itemName) const;
    void PrintAllFrequencies() const;
    void PrintHistogram() const;
};

#endif
