#include "GroceryTracker.h"

#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;

GroceryTracker::GroceryTracker(const string& inputFile, const string& backupFile)
    : inputFileName(inputFile), backupFileName(backupFile) {
}

string GroceryTracker::NormalizeItem(const string& item) const {
    if (item.empty()) {
        return item;
    }

    string normalized = item;

    for (char& ch : normalized) {
        ch = static_cast<char>(tolower(static_cast<unsigned char>(ch)));
    }

    normalized[0] = static_cast<char>(toupper(static_cast<unsigned char>(normalized[0])));
    return normalized;
}

bool GroceryTracker::LoadData() {
    ifstream inputFile(inputFileName);
    string itemName;

    if (!inputFile.is_open()) {
        cerr << "Error: Could not open input file '" << inputFileName << "'." << endl;
        return false;
    }

    while (inputFile >> itemName) {
        itemName = NormalizeItem(itemName);
        ++itemFrequency[itemName];
    }

    inputFile.close();
    return true;
}

bool GroceryTracker::CreateBackupFile() const {
    ofstream outputFile(backupFileName);

    if (!outputFile.is_open()) {
        cerr << "Error: Could not create backup file '" << backupFileName << "'." << endl;
        return false;
    }

    for (const auto& entry : itemFrequency) {
        outputFile << entry.first << ' ' << entry.second << endl;
    }

    outputFile.close();
    return true;
}

int GroceryTracker::GetItemFrequency(const string& itemName) const {
    string normalizedItem = NormalizeItem(itemName);
    auto foundItem = itemFrequency.find(normalizedItem);

    if (foundItem != itemFrequency.end()) {
        return foundItem->second;
    }

    return 0;
}

void GroceryTracker::PrintAllFrequencies() const {
    cout << "\nItem Purchase Frequencies\n";
    cout << "-------------------------\n";

    for (const auto& entry : itemFrequency) {
        cout << left << setw(15) << entry.first << entry.second << endl;
    }
}

void GroceryTracker::PrintHistogram() const {
    cout << "\nPurchase Histogram\n";
    cout << "------------------\n";

    for (const auto& entry : itemFrequency) {
        cout << left << setw(15) << entry.first << string(entry.second, '*') << endl;
    }
}
