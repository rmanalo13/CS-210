#include "GroceryTracker.h"

#include <iostream>
#include <limits>
#include <string>

using namespace std;

int GetMenuChoice() {
    int choice;

    cout << "\nCorner Grocer Item Tracker\n";
    cout << "1. Search for an item frequency\n";
    cout << "2. Display all item frequencies\n";
    cout << "3. Display histogram\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";

    while (!(cin >> choice) || choice < 1 || choice > 4) {
        cout << "Invalid input. Please enter a number from 1 to 4: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    return choice;
}

int main() {
    GroceryTracker tracker("CS210_Project_Three_Input_File.txt", "frequency.dat");

    if (!tracker.LoadData()) {
        return 1;
    }

    if (!tracker.CreateBackupFile()) {
        return 1;
    }

    int userChoice = 0;

    while (userChoice != 4) {
        userChoice = GetMenuChoice();

        switch (userChoice) {
        case 1: {
            string itemToSearch;
            cout << "Enter the item you want to search for: ";
            getline(cin, itemToSearch);

            cout << itemToSearch << " was purchased "
                 << tracker.GetItemFrequency(itemToSearch)
                 << " time(s)." << endl;
            break;
        }
        case 2:
            tracker.PrintAllFrequencies();
            break;
        case 3:
            tracker.PrintHistogram();
            break;
        case 4:
            cout << "Exiting program. Goodbye!" << endl;
            break;
        default:
            cout << "Unexpected menu option." << endl;
            break;
        }
    }

    return 0;
}
